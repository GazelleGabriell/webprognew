<h1>Tugas Web Programming</h1>
<a class="nav-link active text-info " aria-current="page" href="gamelist/home">Click me!</a>

<?php /**PATH D:\Binus\Semester 7\GSLC1WebProg\GSLC1WebProg\resources\views/welcome.blade.php ENDPATH**/ ?>