<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('navbar'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-8">
            <h3 class="p-2 bg-warning text-dark mt-5 rounded-3">Game Add</h3>
            <table class="table">
                <form action="<?php echo e(route('addlogic')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div>
                        <input type="number" placeholder="Game Number" name="game_id">
                    </div>
                    <div>
                        <input type="text" placeholder="Game Name" name="game_name">
                    </div>
                    <div>
                        <input type="text" placeholder="Game Genre" name="game_genre">
                    </div>
                    <div>
                        <input type="text" placeholder="Game Price" name="game_price">
                    </div>
                    <div>
                        <button type="submit" class="btn btn-success" name="submit">Save</button>
                    </div>
                </form>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Semester 7\GSLC1WebProg\GSLC1WebProg\resources\views/add.blade.php ENDPATH**/ ?>