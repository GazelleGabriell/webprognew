<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('navbar'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-8">
            <h3 class="p-2 bg-warning text-dark mt-5 rounded-3">Game List</h3>
            <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID Game</th>
                    <th scope="col">Name Game</th>
                    <th scope="col">Genre Game</th>
                    <th scope="col">Price Game</th>
                </tr>
            </thead>
            <tbody class="bg-light">
                    <tr>
                    <?php $__currentLoopData = $gamelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($game->id_game); ?></td>
                            <td><?php echo e($game->nama_game); ?></td>
                            <td><?php echo e($game->genre_game); ?></td>
                            <td><?php echo e($game->price_game); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Semester 7\GSLC1WebProg\GSLC1WebProg\resources\views/home.blade.php ENDPATH**/ ?>