<h1>GSLC Blade Feature</h1>

<?php /**PATH D:\Binus\Semester 7\GSLC1WebProg\GSLC1WebProg\resources\views/header.blade.php ENDPATH**/ ?>